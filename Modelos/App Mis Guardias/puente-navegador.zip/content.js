/* Se ejecuta dentro de la página de SIGA, con la sesión del abogado ya abierta (tarjeta).
   Lee sus datos y los devuelve con la misma forma que entiende la app del móvil.
   Las secciones con datos de clientes (designaciones, asistencias) solo se leen cuando
   el envío va cifrado con contraseña; popup.js las cifra antes de subirlas. */
(function () {
  if (window.__puenteSiga) return;
  window.__puenteSiga = true;

  // Los identificadores de cada letrado (institución e idPersona de SIGA) se configuran en el complemento;
  // no van fijos, para que cada persona use los suyos.
  var SJCS, SECCIONES, SENSIBLES;
  function cfgSiga() { return new Promise(function (res) { try { chrome.storage.sync.get(["idInstitucion", "idPersona"], function (c) { res(c || {}); }); } catch (e) { res({}); } }); }
  function guardarIds(inst, per) { try { chrome.storage.sync.set({ idInstitucion: inst, idPersona: per }); } catch (e) {} }

  // Detecta, de la propia sesión de SIGA del letrado, su idInstitucion y su idPersona,
  // para que no tenga que buscarlos a mano. Mira la URL, los enlaces/formularios, los
  // campos ocultos y los frames de la página.
  function scanDoc(doc, url) {
    var inst = null, per = null;
    try {
      doc.querySelectorAll("input,select").forEach(function (e) {
        var n = (e.name || e.id || "").toLowerCase(), v = (e.value || "").trim();
        if (!/^\d{3,}$/.test(v)) return;
        if (!inst && /idinstitucion/.test(n)) inst = v;
        if (!per && /idpersona/.test(n)) per = v;
      });
    } catch (e) {}
    var txt = (url || "") + " ";
    try { doc.querySelectorAll("a[href],form[action],area[href],iframe[src],frame[src]").forEach(function (e) { txt += " " + (e.getAttribute("href") || e.getAttribute("action") || e.getAttribute("src") || ""); }); } catch (e) {}
    try { txt += " " + doc.documentElement.innerHTML; } catch (e) {}
    if (!inst) { var mi = txt.match(/idInstitucion(?:Pestanha)?=(\d{3,})/i); if (mi) inst = mi[1]; }
    if (!per) { var mp = txt.match(/idPersona(?:Pestanha)?=(\d{3,})/i); if (mp) per = mp[1]; }
    return { inst: inst, per: per };
  }
  function detectarIds() {
    var docs = [{ d: document, u: location.href }];
    try { document.querySelectorAll("iframe,frame").forEach(function (f) { try { if (f.contentDocument) docs.push({ d: f.contentDocument, u: f.src }); } catch (e) {} }); } catch (e) {}
    var inst = null, per = null;
    for (var i = 0; i < docs.length; i++) { var r = scanDoc(docs[i].d, docs[i].u); inst = inst || r.inst; per = per || r.per; if (inst && per) break; }
    return (inst && per) ? { inst: inst, per: per } : null;
  }
  function construir(INST, PERSONA) {
    SJCS = "/SIGA/CEN_SJCS.do?accion=ver&idInstitucion=" + INST + "&idPersona=" + PERSONA + "&tipoAcceso=1";
    var RETEN = "/SIGA/JGR_RetencionesCenso.do?accion=ver&idInstitucionPestanha=" + INST + "&idPersonaPestanha=" + PERSONA;
    var pest = "accion=ver&idInstitucionPestanha=" + INST + "&idPersonaPestanha=" + PERSONA;
    SECCIONES = [
      { id: "calendario",  nombre: "Guardias",               clave: "Fecha Inicio",       url: "/SIGA/JGR_PestanaCalendarioGuardias.do?" + pest, prepara: [] },
      { id: "proximas",    nombre: "Próximas designaciones", clave: "Posición",           url: "/SIGA/JGR_PestanaProximasDesignas.do?" + pest, prepara: [] },
      { id: "facturacion", nombre: "Facturación",            clave: "Nombre Facturación", url: "/SIGA/JGR_PestanaRetencionesFacturacion.do?idInstitucion=" + INST + "&idPersona=" + PERSONA, prepara: [RETEN] },
      { id: "pagos",       nombre: "Pagos",                  clave: "Número de Abono",    url: "/SIGA/JGR_AbonosClienteSJCS.do?idInstitucion=" + INST + "&idPersona=" + PERSONA, prepara: [RETEN] }
    ];
    SENSIBLES = [
      { id: "designas",    nombre: "Designaciones", clave: "Designación",      url: "/SIGA/JGR_PestanaDesignas.do?" + pest, prepara: [], baseDo: "JGR_PestanaDesignas.do",
        filaRe: /^\d{3,4}\/\d+/,
        // Replica el botón Buscar de SIGA con "sólo pendientes" y "búsqueda exacta" destildados y el año vacío → todas.
        override: { set: { anio: "", anioEJG: "", anioDesgina: "", mostrarTodas: "false", chkBusqExactaInteresado: "false", activarRestriccionesFicha: "false" }, uncheck: ["mostrarSoloPendientes"] } },
      { id: "asistencias", nombre: "Asistencias",   clave: "Fecha Asistencia", url: "/SIGA/JGR_AsistenciasLetrado.do?" + pest, prepara: [], baseDo: "JGR_AsistenciasLetrado.do" }
    ];
  }

  function norm(s) { return (s || "").replace(/ /g, " ").replace(/\s+/g, " ").trim(); }
  function plain(s) { return norm(s).toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, ""); }
  function progreso(txt) { try { chrome.runtime.sendMessage({ tipo: "progreso", texto: txt }); } catch (e) {} }
  function dec(buf) { return new TextDecoder("windows-1252").decode(buf); }
  function get(url) { return fetch(url + (url.indexOf("?") < 0 ? "?" : "&") + "granotmp=" + Date.now(), { credentials: "include" }).then(function (r) { return r.arrayBuffer(); }).then(dec); }
  async function post(url, cuerpo) { var r = await fetch(url, { method: "POST", credentials: "include", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: cuerpo }); return { status: r.status, texto: dec(await r.arrayBuffer()) }; }

  function cabeceras(doc) {
    var out = [];
    doc.querySelectorAll("table").forEach(function (t) { var tr = t.querySelector("tr"); if (!tr) return; var c = []; for (var i = 0; i < tr.cells.length; i++) c.push(norm(tr.cells[i].innerText || tr.cells[i].textContent)); if (c.join("").length) out.push(c.join(" | ").slice(0, 110)); });
    return out.slice(0, 6);
  }
  function dumpForms(doc) {
    var out = [];
    doc.querySelectorAll("form").forEach(function (f) {
      var modo = f.querySelector("[name=modo]"), campos = [];
      f.querySelectorAll("input,select,textarea").forEach(function (e) { if (e.name) campos.push(e.name); });
      out.push({ name: f.getAttribute("name"), action: (f.getAttribute("action") || "").slice(0, 70), modo: modo ? modo.value : null, campos: campos.slice(0, 30) });
    });
    return out.slice(0, 10);
  }
  function parseTabla(html, clave, filaRe) {
    var doc = new DOMParser().parseFromString(html, "text/html");
    var hayLogin = !!doc.querySelector('input[type=password]');
    var k = plain(clave), header = null, rows = [], filas = doc.querySelectorAll("tr");
    for (var i = 0; i < filas.length; i++) {
      var tr = filas[i];
      // Las designaciones con actuaciones llevan una tabla anidada: con filaRe NO saltamos esas filas.
      if (!filaRe && tr.querySelector("table")) continue;
      var c = []; for (var j = 0; j < tr.cells.length; j++) c.push(norm(tr.cells[j].innerText || tr.cells[j].textContent));
      if (!header) { for (var h = 0; h < c.length; h++) { var p = plain(c[h]); if (p === k || (k.length > 4 && p.indexOf(k) >= 0)) { header = c; break; } } continue; }
      var ok;
      if (filaRe) ok = filaRe.test(c[0]); // la fila es válida si su primera celda es un nº de designación
      else ok = c.length >= header.length - 2 && c[0] && plain(c[0]) !== plain(header[0]) && !(/registros/i.test(c.join(" ")) && c.length < 4);
      if (!ok) continue;
      rows.push(c);
    }
    var pag = null, m = (doc.body ? doc.body.innerText : "").match(/(\d+)\s+registros?\s*,?\s*mostrando\s+(\d+)\s+a\s+(\d+)/i);
    if (m) pag = { total: +m[1], from: +m[2], to: +m[3] };
    var form = doc.querySelector('form[name="formPaginador"], form#formPaginador'), paginador = null;
    if (form) {
      var campos = {}; form.querySelectorAll("input,select").forEach(function (el) { if (el.name) campos[el.name] = el.value || ""; });
      // Cada pestaña declara en su función paginar() el "modo" que usa para pasar de página
      // (guardias/asistencias: buscarInit; designaciones: buscarPor). Lo leemos de la propia página.
      var mm = html.match(/formPaginador\.modo\.value\s*=\s*["']([^"']+)["']/);
      paginador = { action: form.getAttribute("action"), campos: campos, modo: mm ? mm[1] : "buscarInit" };
    }
    return { doc: doc, header: header, rows: rows, pag: pag, paginador: paginador, login: hayLogin, headersVistos: cabeceras(doc), len: html.length };
  }

  // Envía el formulario de búsqueda real que trae la página (como el botón Buscar).
  async function enviarFormulario(doc, baseDo, modoForzar, override) {
    var elegido = null;
    doc.querySelectorAll("form").forEach(function (f) {
      var a = f.getAttribute("action") || "", n = (f.getAttribute("name") || "").toLowerCase();
      if (a.indexOf(baseDo) >= 0 && n.indexOf("paginador") < 0) elegido = elegido || f;
    });
    if (!elegido) return null;
    var pares = [];
    elegido.querySelectorAll("input,select,textarea").forEach(function (e) {
      if (!e.name) return;
      if (e.type === "checkbox" || e.type === "radio") { if (e.checked) pares.push([e.name, e.value]); }
      else pares.push([e.name, e.value || ""]);
    });
    if (modoForzar) { var tiene = false; pares = pares.map(function (p) { if (p[0] === "modo") { tiene = true; return ["modo", modoForzar]; } return p; }); if (!tiene) pares.push(["modo", modoForzar]); }
    if (override) {
      if (override.uncheck) pares = pares.filter(function (p) { return override.uncheck.indexOf(p[0]) < 0; });
      if (override.set) Object.keys(override.set).forEach(function (k) { var hecho = false; pares = pares.map(function (p) { if (p[0] === k) { hecho = true; return [k, override.set[k]]; } return p; }); if (!hecho) pares.push([k, override.set[k]]); });
    }
    var action = elegido.getAttribute("action");
    var body = pares.map(function (p) { return encodeURIComponent(p[0]) + "=" + encodeURIComponent(p[1]); }).join("&");
    var r = await post(action, body);
    return { status: r.status, texto: r.texto, action: action, body: body };
  }

  function conPagina(body, p) {
    if (/[?&]?pagina=/.test(body)) return body.replace(/(pagina=)\d+/, "$1" + p);
    return body + "&pagina=" + p;
  }

  // Cuenta las lupas (actuaciones justificadas) por designación, recorriendo las filas de actuación
  // que cuelgan de cada designación. Devuelve {numeroDesignacion: nºlupas}.
  function lupasPorDesigna(doc, diag) {
    var map = {}, trs = doc.querySelectorAll("tr"), cur = null;
    for (var i = 0; i < trs.length; i++) {
      var tr = trs[i]; if (tr.querySelector("table") || !tr.cells[0]) continue;
      var c0 = norm(tr.cells[0].innerText || tr.cells[0].textContent);
      if (/^\d{3,4}\/\d+/.test(c0)) { cur = c0; if (!(cur in map)) map[cur] = 0; continue; } // la fila de la designación no cuenta
      if (!cur) continue;
      var cuenta = 0, iconos = [];
      tr.querySelectorAll("img").forEach(function (im) {
        var bn = (im.getAttribute("src") || "").split("/").pop().split(".")[0];
        var meta = (bn + " " + (im.getAttribute("onclick") || "") + " " + (im.getAttribute("title") || "") + " " + (im.getAttribute("alt") || "")).toLowerCase();
        iconos.push(bn);
        if (/consultar|lupa|buscar|ver|justif/.test(meta) && !/edit|borra|upload|download|descarg|subir/.test(meta)) cuenta++;
      });
      map[cur] += cuenta;
      if (diag && diag.length < 8 && iconos.length) diag.push({ d: cur.slice(0, 12), ic: iconos.slice(0, 8), n: cuenta });
    }
    return map;
  }

  async function paginar(res, s, dbg, searchCtx) {
    var vistos = {}, todas = [];
    function add(rows) { var nuevas = 0; rows.forEach(function (row) { var key = row.join("|"); if (!vistos[key]) { vistos[key] = 1; todas.push(row); nuevas++; } }); return nuevas; }
    var lupaMap = null, lupaDiag = null;
    if (s.id === "designas") { lupaDiag = []; lupaMap = lupasPorDesigna(res.doc, lupaDiag); }
    add(res.rows);
    var paginador = res.paginador, pag = res.pag, p = 1;
    var totalEsperado = pag ? pag.total : (searchCtx ? 9999 : 0);
    if (!paginador && !searchCtx) { dbg.filas = todas.length; return todas; }
    while (todas.length < totalEsperado && p < 25) {
      p++;
      progreso(s.nombre + " (" + todas.length + (pag ? " de " + pag.total : "") + ")…");
      // Método A: repetir el formulario de búsqueda con el número de página (listas de búsqueda).
      // Método B: el paginador normal (listas directas como guardias o pagos).
      var intentos = [];
      if (searchCtx) {
        intentos.push({ via: "form-init", action: searchCtx.action, body: conPagina(searchCtx.body, p) });
        intentos.push({ via: "form-buscar", action: searchCtx.action, body: conPagina(searchCtx.body.replace(/modo=[^&]*/, "modo=buscar"), p) });
        intentos.push({ via: "form-paginar", action: searchCtx.action, body: conPagina(searchCtx.body.replace(/modo=[^&]*/, "modo=paginar"), p) });
      }
      if (paginador) { var campos = Object.assign({}, paginador.campos); campos.modo = paginador.modo || "buscarInit"; campos.pagina = String(p); if ("Seleccion" in campos) campos.Seleccion = ""; intentos.push({ via: "paginador(" + campos.modo + ")", action: paginador.action, body: Object.keys(campos).map(function (k) { return encodeURIComponent(k) + "=" + encodeURIComponent(campos[k]); }).join("&") }); }
      var nuevas = 0, usado = null, r2 = null;
      for (var t = 0; t < intentos.length; t++) {
        var rp = await post(intentos[t].action, intentos[t].body);
        r2 = parseTabla(rp.texto, s.clave, s.filaRe);
        var n = add(r2.rows);
        if (n > 0) { nuevas = n; usado = intentos[t].via; if (lupaMap) { var m2 = lupasPorDesigna(r2.doc, lupaDiag); for (var kk in m2) lupaMap[kk] = (lupaMap[kk] || 0) + m2[kk]; } if (r2.paginador) paginador = r2.paginador; break; }
      }
      if (dbg.pasos.length < 3) dbg.pasos.push({ p: p, nuevas: nuevas, via: usado, cab: r2 ? r2.headersVistos.slice(0, 2) : null });
      if (!nuevas) break;
    }
    if (lupaMap) { todas = todas.map(function (row) { return row.concat([String(lupaMap[row[0]] != null ? lupaMap[row[0]] : 0)]); }); dbg.lupas = lupaDiag; }
    dbg.filas = todas.length;
    return todas;
  }

  // Cuenta actuaciones justificadas (lupa) por designación y recoge los nombres de iconos vistos.
  function contarLupas(doc, map, iconSet) {
    var trs = doc.querySelectorAll("tr"), cur = null;
    for (var i = 0; i < trs.length; i++) {
      var tr = trs[i]; if (!tr.cells[0]) continue;
      var c0 = norm(tr.cells[0].innerText || tr.cells[0].textContent);
      if (/^\d{3,4}\/\d+/.test(c0)) { cur = c0; if (!(cur in map)) map[cur] = 0; continue; }
      if (!cur) continue;
      var just = false;
      tr.querySelectorAll("img").forEach(function (im) {
        var bn = (im.getAttribute("src") || "").split("/").pop().split(".")[0].toLowerCase();
        if (iconSet) iconSet[bn] = (iconSet[bn] || 0) + 1;
        if (bn === "bdownload" || /lupa|consultar|verjust|bver/.test(bn)) just = true;
      });
      if (just) map[cur]++;
    }
  }

  // Designaciones: se busca AÑO POR AÑO (buscarInit aplica el criterio) y se junta todo, para traerlas todas.
  async function leerDesignas(formDoc, s, dbg) {
    var now = new Date().getFullYear(), vistos = {}, todas = [], lupaMap = {}, iconSet = {}, header = null, anios = [], vacios = 0;
    for (var Y = now; Y >= now - 9; Y--) {
      progreso("Designaciones (año " + Y + ")…");
      var ov = { set: { anio: String(Y), anioEJG: "", mostrarTodas: "false", chkBusqExactaInteresado: "false", activarRestriccionesFicha: "false" }, uncheck: ["mostrarSoloPendientes"] };
      var rr; try { rr = await enviarFormulario(formDoc, s.baseDo, "buscarInit", ov); } catch (e) { rr = null; }
      if (!rr) { anios.push({ y: Y, nuevas: 0 }); vacios++; if (vacios >= 2 && Y < now) break; continue; }
      var rp = parseTabla(rr.texto, s.clave, s.filaRe), nuevasAnio = 0;
      if (rp.header) {
        header = header || rp.header;
        rp.rows.forEach(function (row) { var k = row[0]; if (!(k in vistos)) { vistos[k] = 1; todas.push(row); nuevasAnio++; } });
        contarLupas(rp.doc, lupaMap, iconSet);
        var pag = rp.pag, paginador = rp.paginador, p = 1;
        while (pag && paginador && p < 12) {
          p++;
          var campos = Object.assign({}, paginador.campos); campos.modo = paginador.modo || "buscarPor"; campos.pagina = String(p); if ("Seleccion" in campos) campos.Seleccion = "";
          var body = Object.keys(campos).map(function (k) { return encodeURIComponent(k) + "=" + encodeURIComponent(campos[k]); }).join("&");
          var r2 = parseTabla((await post(paginador.action, body)).texto, s.clave, s.filaRe), add2 = 0;
          r2.rows.forEach(function (row) { var k = row[0]; if (!(k in vistos)) { vistos[k] = 1; todas.push(row); nuevasAnio++; add2++; } });
          contarLupas(r2.doc, lupaMap, iconSet);
          if (!add2) break;
          if (r2.pag) pag = r2.pag; if (r2.paginador) paginador = r2.paginador;
          if (pag && p * 20 >= pag.total) break;
        }
      }
      anios.push({ y: Y, nuevas: nuevasAnio, total: rp.pag ? rp.pag.total : null });
      if (nuevasAnio === 0) { vacios++; if (vacios >= 2 && Y < now) break; } else vacios = 0;
    }
    dbg.anios = anios; dbg.iconos = iconSet; dbg.filas = todas.length;
    var rows = todas.map(function (row) { return row.concat([String(lupaMap[row[0]] != null ? lupaMap[row[0]] : 0)]); });
    return { header: (header || []).concat(["Justificadas"]), rows: rows, estado: "ok", dbg: dbg };
  }

  async function leerSeccion(s) {
    for (var i = 0; i < s.prepara.length; i++) { try { await get(s.prepara[i]); } catch (e) {} }
    var html = await get(s.url);
    var res = parseTabla(html, s.clave, s.filaRe);
    var dbg = { len: res.len, pag: res.pag, cab: res.headersVistos, paginador: res.paginador ? res.paginador.action : null, pasos: [] };
    if (res.login) throw { login: true };
    if (s.id === "designas") return await leerDesignas(res.doc, s, dbg);
    var searchCtx = null;
    if (!res.header && s.baseDo) {
      dbg.formsCold = dumpForms(res.doc);
      var bots = [];
      res.doc.querySelectorAll("input[type=button],input[type=submit],button,a").forEach(function (bt) {
        var oc = bt.getAttribute("onclick") || "", t = (bt.value || bt.textContent || bt.getAttribute("title") || "").trim();
        if (/buscar|consultar|justif|lupa/i.test(t + " " + oc)) bots.push({ t: t.slice(0, 30), oc: oc.slice(0, 90) });
      });
      dbg.botones = bots.slice(0, 8);
      var ibf = html.search(/function\s+\w*[Bb]uscar\w*\s*\(/);
      dbg.buscarFn = ibf >= 0 ? html.substr(ibf, 800) : null;
      // Campos (nombre y valor) del formulario de búsqueda tal cual llega: vacíos o banderas/años, sin datos de clientes
      var fbusq = null;
      res.doc.querySelectorAll("form").forEach(function (f) { var a = f.getAttribute("action") || "", n = (f.getAttribute("name") || "").toLowerCase(); if (a.indexOf(s.baseDo) >= 0 && n.indexOf("paginador") < 0) fbusq = fbusq || f; });
      if (fbusq) { dbg.formCampos = []; fbusq.querySelectorAll("input,select,textarea").forEach(function (e) { if (e.name) dbg.formCampos.push({ n: e.name, t: e.type, v: (e.value || "").slice(0, 20), chk: (e.type === "checkbox" || e.type === "radio") ? e.checked : undefined }); }); dbg.formCampos = dbg.formCampos.slice(0, 40); }
      dbg.intentos = [];
      // Paso 1: "buscarInit" para fijar la sesión en el servidor (es la vista por defecto).
      try { await enviarFormulario(res.doc, s.baseDo, "buscarInit", null); } catch (e) {}
      // Paso 2: "buscar" real. Con override (año vacío, sin tics) trae TODAS; sin él, la vista normal.
      var candidatos = [];
      if (s.override) candidatos.push({ how: "buscarPor+override", mo: "buscarPor", ov: s.override });
      if (s.override) candidatos.push({ how: "buscar+override", mo: "buscar", ov: s.override });
      candidatos.push({ how: "buscar", mo: "buscar", ov: null });
      candidatos.push({ how: "buscarInit", mo: "buscarInit", ov: null });
      for (var e = 0; e < candidatos.length; e++) {
        try {
          var rr = await enviarFormulario(res.doc, s.baseDo, candidatos[e].mo, candidatos[e].ov);
          if (!rr) { dbg.intentos.push({ how: candidatos[e].how, nulo: true }); continue; }
          var rp = parseTabla(rr.texto, s.clave, s.filaRe);
          dbg.intentos.push({ how: candidatos[e].how, http: rr.status, len: rr.texto.length, hay: !!rp.header, filas: rp.rows.length, pag: rp.pag, cab: rp.headersVistos.slice(0, 2), muestra: rp.header ? null : rr.texto.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 170) });
          if (rp.header) {
            res = rp; dbg.buscado = candidatos[e].how; searchCtx = { action: rr.action, body: rr.body };
            var ip = rr.texto.indexOf("function paginar"); if (ip < 0) ip = rr.texto.indexOf("paginar(");
            dbg.pagJs = ip >= 0 ? rr.texto.substr(ip, 240) : null;
            dbg.resultForms = dumpForms(rp.doc);
            break;
          }
        } catch (ex) { dbg.intentos.push({ how: candidatos[e].how, err: String(ex).slice(0, 60) }); }
      }
    }
    if (!res.header) return { header: [], rows: [], estado: "sin-datos", dbg: dbg };
    if (s.id === "designas") { // ¿cuál es la marca de la lupa? (nombres de iconos y funciones, sin datos de clientes)
      dbg.celda0 = []; res.doc.querySelectorAll("tr").forEach(function (tr) { if (tr.cells[0]) { var t = norm(tr.cells[0].innerText || tr.cells[0].textContent); if (t) dbg.celda0.push(t.slice(0, 22)); } }); dbg.celda0 = dbg.celda0.slice(0, 45);
      dbg.marcadores = []; var trs = res.doc.querySelectorAll("tr"), cnt = 0;
      for (var mi = 0; mi < trs.length && cnt < 8; mi++) {
        var tr = trs[mi]; if (tr.querySelector("table") || !tr.cells[0]) continue;
        var c0 = norm(tr.cells[0].innerText || tr.cells[0].textContent); if (!/^\d/.test(c0)) continue;
        var imgs = [], fns = [];
        tr.querySelectorAll("img").forEach(function (im) { imgs.push((im.getAttribute("src") || "").split("/").pop().split("_")[0].split(".")[0]); });
        tr.querySelectorAll("[onclick]").forEach(function (el) { var m = (el.getAttribute("onclick") || "").match(/([A-Za-z_]\w*)\s*\(/); if (m) fns.push(m[1]); });
        dbg.marcadores.push({ id: c0.slice(0, 14), imgs: imgs.slice(0, 6), fns: fns.slice(0, 6) }); cnt++;
      }
    }
    var todas = await paginar(res, s, dbg, searchCtx);
    var header = s.id === "designas" ? res.header.concat(["Justificadas"]) : res.header;
    return { header: header, rows: todas, estado: "ok", dbg: dbg };
  }

  async function recolectar(incluirSensibles) {
    var c = await cfgSiga();
    var inst = (c.idInstitucion || "").toString().trim(), per = (c.idPersona || "").toString().trim();
    if (!inst || !per) {
      var d = detectarIds();
      if (d) { inst = d.inst; per = d.per; guardarIds(inst, per); }
    }
    if (!inst || !per) return { error: "No he podido detectar tus datos de SIGA. Abre tu sección de Turno de Oficio en SIGA (donde ves tus guardias) y vuelve a pulsar Enviar. Si sigue sin funcionar, puedes ponerlos a mano en Configuración." };
    construir(inst, per);
    try { await get(SJCS); } catch (e) {}
    var lista = incluirSensibles ? SECCIONES.concat(SENSIBLES) : SECCIONES;
    var salida = { _actualizado: Date.now(), _origen: "puente" }, errores = [];
    for (var i = 0; i < lista.length; i++) {
      var s = lista[i]; progreso("Leyendo " + s.nombre + "…");
      try {
        var r = await leerSeccion(s);
        salida[s.id] = { header: r.header, rows: r.rows, estado: r.estado };
        if (r.estado !== "ok") errores.push(s.nombre + ": sin datos");
      } catch (e) { if (e && e.login) return { error: "login" }; errores.push(s.nombre + ": " + (e && e.message ? e.message : "error")); }
    }
    return { datos: salida, errores: errores };
  }

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (msg && msg.tipo === "recolectar") {
      recolectar(!!msg.incluirSensibles).then(sendResponse, function (e) { sendResponse({ error: (e && e.message) || "error" }); });
      return true;
    }
  });
})();
