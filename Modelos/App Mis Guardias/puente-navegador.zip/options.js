const $ = function (id) { return document.getElementById(id); };

chrome.storage.sync.get(["token", "owner", "repo", "pass", "idInstitucion", "idPersona"], function (c) {
  if (c.token) $("token").value = c.token;
  $("owner").value = c.owner || "";
  $("repo").value = c.repo || "siga-app";
  if (c.pass) $("pass").value = c.pass;
  if (c.idInstitucion) $("idInstitucion").value = c.idInstitucion;
  if (c.idPersona) $("idPersona").value = c.idPersona;
});

// Evita que el navegador autorrellene estos campos con contraseñas guardadas:
// empiezan bloqueados (readonly) y se liberan al pulsarlos para poder escribir.
["token", "owner", "repo", "pass"].forEach(function (id) {
  var e = $(id);
  if (!e) return;
  function liberar() { e.removeAttribute("readonly"); }
  e.addEventListener("focus", liberar);
  e.addEventListener("mousedown", liberar);
});

$("guardar").addEventListener("click", function () {
  var token = $("token").value.trim(), owner = $("owner").value.trim(), repo = $("repo").value.trim(), pass = $("pass").value;
  var idInstitucion = $("idInstitucion").value.trim(), idPersona = $("idPersona").value.trim();
  if (!token || !owner || !repo) { $("estado").style.color = "#b8430e"; $("estado").textContent = "Rellena el token, el usuario y el repositorio."; return; }
  if (!pass) { $("estado").style.color = "#b8430e"; $("estado").textContent = "Pon una contraseña de cifrado: es obligatoria (y la misma en el móvil)."; return; }
  chrome.storage.sync.set({ token: token, owner: owner, repo: repo, pass: pass, idInstitucion: idInstitucion, idPersona: idPersona }, function () {
    $("estado").style.color = "#2c7a4b";
    $("estado").textContent = "Guardado. Ya puedes cerrar esta pestaña y usar el botón del complemento.";
  });
});
