const $ = function (id) { return document.getElementById(id); };

function cfg() {
  return new Promise(function (res) {
    chrome.storage.sync.get(["token", "owner", "repo", "pass", "ultimo"], function (c) { res(c || {}); });
  });
}
function b64str(str) { var bytes = new TextEncoder().encode(str); return b64bytes(bytes); }
function b64bytes(bytes) { var bin = ""; for (var i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]); return btoa(bin); }

async function cifrar(pass, texto) {
  var enc = new TextEncoder();
  var salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
  var base = await crypto.subtle.importKey("raw", enc.encode(pass), "PBKDF2", false, ["deriveKey"]);
  var key = await crypto.subtle.deriveKey({ name: "PBKDF2", salt: salt, iterations: 200000, hash: "SHA-256" }, base, { name: "AES-GCM", length: 256 }, false, ["encrypt"]);
  var ct = await crypto.subtle.encrypt({ name: "AES-GCM", iv: iv }, key, enc.encode(texto));
  return JSON.stringify({ _cifrado: true, v: 1, kdf: "PBKDF2", hash: "SHA-256", iter: 200000, salt: b64bytes(salt), iv: b64bytes(iv), ct: b64bytes(new Uint8Array(ct)) });
}

chrome.runtime.onMessage.addListener(function (msg) { if (msg && msg.tipo === "progreso") $("estado").textContent = msg.texto; });

async function tabSiga() {
  var tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  var t = tabs[0];
  if (!t || !/^https:\/\/siga\.redabogacia\.org\//.test(t.url || "")) return null;
  return t;
}

async function subir(c, path, contenido, obligatorio) {
  var base = "https://api.github.com/repos/" + c.owner + "/" + c.repo + "/contents/" + path;
  var cab = { "Authorization": "Bearer " + c.token, "Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28" };
  try {
    var sha = null, g = await fetch(base, { headers: cab });
    if (g.status === 200) { sha = (await g.json()).sha; }
    else if (g.status !== 404) { throw new Error("GitHub respondió " + g.status + " al leer. Revisa el token y el repositorio. " + (await g.text()).slice(0, 120)); }
    var cuerpo = { message: path + " " + new Date().toISOString(), content: b64str(contenido) };
    if (sha) cuerpo.sha = sha;
    var p = await fetch(base, { method: "PUT", headers: cab, body: JSON.stringify(cuerpo) });
    if (!p.ok) throw new Error("GitHub respondió " + p.status + " al guardar. " + (await p.text()).slice(0, 160));
  } catch (e) { if (obligatorio) throw e; }
}

async function enviar() {
  $("estado").className = "estado"; $("estado").textContent = "";
  var c = await cfg();
  if (!c.token || !c.owner || !c.repo) { $("estado").className = "estado err"; $("estado").textContent = "Falta configurar el token y el repositorio. Pulsa Configuración."; return; }
  if (!c.pass) { $("estado").className = "estado err"; $("estado").textContent = "Falta la contraseña de cifrado (es obligatoria). Pulsa Configuración."; return; }
  var t = await tabSiga();
  if (!t) { $("estado").className = "estado err"; $("estado").textContent = "Abre SIGA y entra con tu tarjeta en esta pestaña, luego vuelve a pulsar."; return; }
  var cifrado = true;
  $("enviar").disabled = true; $("estado").textContent = "Leyendo SIGA…";
  try {
    var r = await new Promise(function (res, rej) {
      chrome.tabs.sendMessage(t.id, { tipo: "recolectar", incluirSensibles: cifrado }, function (resp) {
        if (chrome.runtime.lastError) rej(new Error("No he podido leer la página. Recarga SIGA y prueba otra vez."));
        else res(resp);
      });
    });
    if (!r) throw new Error("Sin respuesta de la página.");
    if (r.error === "login") throw new Error("Tu sesión de SIGA no está abierta. Entra con la tarjeta y repite.");
    if (r.error) throw new Error(r.error);
    var n = (r.datos.calendario && r.datos.calendario.rows.length) || 0;
    $("estado").textContent = "Subiendo al móvil" + (cifrado ? " (cifrado)" : "") + "…";
    var contenido = cifrado ? await cifrar(c.pass, JSON.stringify(r.datos)) : JSON.stringify(r.datos);
    await subir(c, "puente/guardias.json", contenido, true);
    var fecha = new Date(); chrome.storage.sync.set({ ultimo: fecha.getTime() });
    $("estado").className = "estado ok";
    $("estado").textContent = "Enviado" + (cifrado ? " y cifrado" : "") + ". En el móvil, abre Mis guardias y pulsa Actualizar." + (r.errores && r.errores.length ? "\n(" + r.errores.join("; ") + ")" : "");
    $("cuando").textContent = fecha.toLocaleString("es-ES");
  } catch (e) { $("estado").className = "estado err"; $("estado").textContent = e.message || String(e); }
  finally { $("enviar").disabled = false; }
}

(async function () {
  var c = await cfg();
  var listo = c.token && c.owner && c.repo && c.pass;
  $("aviso").textContent = listo
    ? "Entra en SIGA con tu tarjeta y pulsa Enviar al móvil. Se enviará cifrado, con designaciones y asistencias."
    : "Primero pulsa Configuración y rellena el token, el repositorio y la contraseña de cifrado.";
  if (c.ultimo) $("cuando").textContent = "Último envío: " + new Date(c.ultimo).toLocaleString("es-ES");
  $("enviar").addEventListener("click", enviar);
  $("opciones").addEventListener("click", function (e) { e.preventDefault(); chrome.runtime.openOptionsPage(); });
})();
