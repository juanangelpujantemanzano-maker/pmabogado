# Puente SIGA → Mis guardias (complemento del navegador)

Lee de SIGA, con tu sesión ya abierta (tarjeta ACA), tus **guardias, próximas
designaciones, facturación y pagos** y los envía a la app del móvil a través de
tu repositorio privado de GitHub. **No lee designaciones ni asistencias**, porque
contienen datos de clientes: esos se quedan en el ordenador.

## Instalación (una sola vez)

1. Abre Chrome o Edge y ve a `chrome://extensions` (en Edge, `edge://extensions`).
2. Activa el **Modo de desarrollador** (arriba a la derecha).
3. Pulsa **Cargar descomprimida** y elige esta carpeta `puente-navegador`.
4. Aparecerá el complemento Puente SIGA. Ánclalo a la barra si quieres tenerlo a mano.

## Configuración (una sola vez)

1. Crea un token en GitHub: `github.com/settings/personal-access-tokens` →
   Generate new token → **Fine-grained**.
   - Repository access: **Only select repositories** → `siga-app`.
   - Permissions → Repository permissions → **Contents**: *Read and write*.
2. Copia el token (empieza por `github_pat_`).
3. En el complemento, pulsa **Configuración** y pega el token, tu usuario y `siga-app`.

El mismo token se pone también en la app del móvil, en **Configurar puente**.

## Uso diario

1. En el ordenador, entra en SIGA con tu tarjeta.
2. Pulsa el botón del complemento → **Enviar al móvil**.
3. En el móvil, abre Mis guardias y pulsa **Actualizar**.
